a = 123
b = 555
a1 = a // 100
a2 = a // 10 % 10
a3 = a % 10
b1 = b // 100
b2 = b // 10 % 10
b3 = b % 10
print(a1 + a2 + a3)
print(b1 + b2 + b3)