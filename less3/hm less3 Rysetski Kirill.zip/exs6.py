a = 200
b = 123

print(a % 10)
print(b % 10)

num = 587
last_digit = int(str(num)[-1])
print(last_digit)
