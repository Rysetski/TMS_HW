print("hello world")
print("It is my first python program")
print("And it is the end of my program")
print("Bye-bye")